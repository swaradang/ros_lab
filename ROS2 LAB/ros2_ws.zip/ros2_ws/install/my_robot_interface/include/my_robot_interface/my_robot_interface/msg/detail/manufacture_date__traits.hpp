// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from my_robot_interface:msg/ManufactureDate.idl
// generated code does not contain a copyright notice

#ifndef MY_ROBOT_INTERFACE__MSG__DETAIL__MANUFACTURE_DATE__TRAITS_HPP_
#define MY_ROBOT_INTERFACE__MSG__DETAIL__MANUFACTURE_DATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "my_robot_interface/msg/detail/manufacture_date__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace my_robot_interface
{

namespace msg
{

inline void to_flow_style_yaml(
  const ManufactureDate & msg,
  std::ostream & out)
{
  out << "{";
  // member: date
  {
    out << "date: ";
    rosidl_generator_traits::value_to_yaml(msg.date, out);
    out << ", ";
  }

  // member: month
  {
    out << "month: ";
    rosidl_generator_traits::value_to_yaml(msg.month, out);
    out << ", ";
  }

  // member: year
  {
    out << "year: ";
    rosidl_generator_traits::value_to_yaml(msg.year, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ManufactureDate & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: date
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "date: ";
    rosidl_generator_traits::value_to_yaml(msg.date, out);
    out << "\n";
  }

  // member: month
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "month: ";
    rosidl_generator_traits::value_to_yaml(msg.month, out);
    out << "\n";
  }

  // member: year
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "year: ";
    rosidl_generator_traits::value_to_yaml(msg.year, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ManufactureDate & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace my_robot_interface

namespace rosidl_generator_traits
{

[[deprecated("use my_robot_interface::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const my_robot_interface::msg::ManufactureDate & msg,
  std::ostream & out, size_t indentation = 0)
{
  my_robot_interface::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use my_robot_interface::msg::to_yaml() instead")]]
inline std::string to_yaml(const my_robot_interface::msg::ManufactureDate & msg)
{
  return my_robot_interface::msg::to_yaml(msg);
}

template<>
inline const char * data_type<my_robot_interface::msg::ManufactureDate>()
{
  return "my_robot_interface::msg::ManufactureDate";
}

template<>
inline const char * name<my_robot_interface::msg::ManufactureDate>()
{
  return "my_robot_interface/msg/ManufactureDate";
}

template<>
struct has_fixed_size<my_robot_interface::msg::ManufactureDate>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<my_robot_interface::msg::ManufactureDate>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<my_robot_interface::msg::ManufactureDate>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // MY_ROBOT_INTERFACE__MSG__DETAIL__MANUFACTURE_DATE__TRAITS_HPP_
